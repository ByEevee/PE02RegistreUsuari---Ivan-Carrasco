package com.example.pe02_registreusuari;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    // Claus dels Extras i codi de petició (compartits amb Activity2)
    public static final String EXTRA_PERSONA = "persona";
    public static final String EXTRA_ACCEPTAT = "acceptat";
    public static final int REQUEST_INFO = 123;

    EditText edtNom, edtCognoms, edtEdat;
    RadioGroup rgMatriculat;
    Button btnMostrarInfo;
    TextView txtPolitica;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        edtNom = findViewById(R.id.edtNom);
        edtCognoms = findViewById(R.id.edtCognoms);
        edtEdat = findViewById(R.id.edtEdat);
        rgMatriculat = findViewById(R.id.rgMatriculat);
        btnMostrarInfo = findViewById(R.id.btnMostrarInfo);
        txtPolitica = findViewById(R.id.txtPolitica);

        btnMostrarInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String nom = edtNom.getText().toString().trim();
                String cognoms = edtCognoms.getText().toString().trim();

                int edat;
                try {
                    edat = Integer.parseInt(edtEdat.getText().toString().trim());
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, R.string.error_edat, Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean matriculat = rgMatriculat.getCheckedRadioButtonId() == R.id.rbSi;

                // Punt extra: objecte Persona (Serializable) passat pel Bundle
                Persona p = new Persona(nom, cognoms, edat, matriculat);

                Intent i = new Intent(MainActivity.this, Activity2.class);
                Bundle container = new Bundle();
                container.putSerializable(EXTRA_PERSONA, p);
                i.putExtras(container);
                startActivityForResult(i, REQUEST_INFO);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case REQUEST_INFO:
                // Si es torna amb l'Enrere del sistema, data és null: no fem res
                if (resultCode == RESULT_OK && data != null) {
                    boolean acceptat = data.getBooleanExtra(EXTRA_ACCEPTAT, false);
                    txtPolitica.setText(acceptat ? R.string.politica_acceptada : R.string.politica_no_acceptada);
                    txtPolitica.setTextColor(ContextCompat.getColor(this, acceptat ? R.color.verd : R.color.vermell));
                }
                break;
        }
    }
}
