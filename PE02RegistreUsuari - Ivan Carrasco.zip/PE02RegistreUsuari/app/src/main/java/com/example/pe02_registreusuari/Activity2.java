package com.example.pe02_registreusuari;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Activity2 extends AppCompatActivity {

    TextView txtNom, txtCognoms, txtEdat, txtMatriculat;
    CheckBox chkPolitica;
    Button btnSalir;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtNom = findViewById(R.id.txtNom);
        txtCognoms = findViewById(R.id.txtCognoms);
        txtEdat = findViewById(R.id.txtEdat);
        txtMatriculat = findViewById(R.id.txtMatriculat);
        chkPolitica = findViewById(R.id.chkPolitica);
        btnSalir = findViewById(R.id.btnSalir);

        // Recuperem la Persona enviada des de MainActivity
        Persona p = (Persona) getIntent().getSerializableExtra(MainActivity.EXTRA_PERSONA);
        if (p != null) {
            txtNom.setText(p.getNom());
            txtCognoms.setText(p.getCognoms());
            txtEdat.setText(String.valueOf(p.getEdat())); // mai setText(int): seria un id de recurs
            txtMatriculat.setText(p.isMatriculat() ? R.string.rb_si : R.string.rb_no);
        }

        btnSalir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent();
                i.putExtra(MainActivity.EXTRA_ACCEPTAT, chkPolitica.isChecked());
                setResult(RESULT_OK, i);
                finish();
            }
        });
    }
}
